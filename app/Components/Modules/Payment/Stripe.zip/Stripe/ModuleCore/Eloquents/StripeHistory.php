<?php

namespace App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents;


use Illuminate\Database\Eloquent\Model;

/**
 * Class PaytmHistory
 * @package App\Components\Modules\Payment\Paytm\Eloquents
 */
class StripeHistory extends Model
{
    protected $guarded = [];

    protected $casts = [
        'getParams' => 'array',
        'postParams' => 'array'
    ];

    protected $table = 'stripe_payment_history';
}