<?php

namespace App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents;

use App\Eloquents\Transaction;
use Illuminate\Database\Eloquent\Model;

/**
 * Class StripeTransaction
 * @package App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents
 */
class StripeTransaction extends Model
{
    protected $guarded = [];

    protected $casts = [
        'data' => 'array'
    ];

    protected $table = 'stripe_transactions';

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    function transaction()
    {
        return $this->belongsTo(Transaction::class, 'local_txn_id');
    }
}