<?php
/**
 *  -------------------------------------------------
 *  Hybrid MLM  Copyright (c) 2018 All Rights Reserved
 *  -------------------------------------------------
 *
 * @author Acemero Technologies Pvt Ltd
 * @link https://www.acemero.com
 * @see https://www.hybridmlm.io
 * @version 1.00
 * @api Laravel 5.4
 */

namespace App\Components\Modules\Payment\Stripe\ModuleCore\Traits;

use App\Blueprint\Services\PaymentServices;
use App\Components\Modules\Payment\Paytm\ModuleCore\Eloquents\PaytmHistory;
use App\Components\Modules\Payment\Paytm\ModuleCore\Eloquents\PaytmInfo;
use App\Components\Modules\Payment\Paytm\ModuleCore\Eloquents\PaytmTransaction;
use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeHistory;
use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeInfo;
use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeTransaction;
use Illuminate\Http\Request;


/**
 * Trait Hooks
 * @package App\Components\Modules\Payment\Stripe\ModuleCore\Traits
 */
trait Hooks
{
    /**
     * @return mixed
     */
    function hooks()
    {
        app()->call([$this, 'registerHooks']);

        app()->call([$this, 'systemReset']);
    }

    /**
     * Register hooks
     *
     * @param PaymentServices $paymentServices
     * @return Void
     */
    public function registerHooks(PaymentServices $paymentServices)
    {
        registerAction('prePaymentProcessAction', function ($request) use ($paymentServices) {

            /** @var Request $request */
            if ($request->input('gateway') != $this->moduleId)
                return;
            $paymentServices->getPayable();
            $paymentServices->setAuthorized(true);
        }, 'root', 10);

//        registerFilter('userAccountInfo', function ($data, $args) {
//            $data = [
//                'stripeInfo' => StripeInfo::find($args['account']->user_id),
//                'moduleId' => $this->moduleId
//            ];
//
//            return view('Payment.Stripe.Views.stripeInfo', $data);
//        }, 'stripePayout', 1);
    }

    /**
     * System refresh
     */
    function systemReset()
    {
        registerFilter('dataTruncate', function ($data, $args) {
            StripeHistory::truncate();
            StripeInfo::truncate();
            StripeTransaction::truncate();
        }, 'systemReset');

        registerFilter('dataSeeding', function ($data, $args) {

        }, 'systemReset');
    }
}