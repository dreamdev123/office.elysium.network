<?php
/**
 *  -------------------------------------------------
 *  Hybrid MLM  Copyright (c) 2018 All Rights Reserved
 *  -------------------------------------------------
 *
 * @author Acemero Technologies Pvt Ltd
 * @link https://www.acemero.com
 * @see https://www.hybridmlm.io
 * @version 1.00
 * @api Laravel 5.4
 */

namespace App\Components\Modules\Payment\Stripe\ModuleCore\Schema;

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Class Setup
 * @package App\Components\Modules\Payment\Paytm\ModuleCore\Schema
 */
class Setup
{
    /**
     * Install stripe module
     */
    static function install()
    {
        if (!Schema::hasTable('stripe_transactions'))
            Schema::create('stripe_transactions', function (Blueprint $table) {
                $table->increments('id');
                $table->text('session_id');
                $table->double('local_txn_id');
                $table->char('context', 50)->nullable();
                $table->text('callback')->nullable();
                $table->integer('sort_order')->nullable();
                $table->double('amount')->nullable();
                $table->longText('data')->nullable();
                $table->boolean('status')->default(0);
                $table->timestamps();
            });

        if (!Schema::hasTable('stripe_payment_history'))
            Schema::create('stripe_payment_history', function (Blueprint $table) {
                $table->increments('id');
                $table->longText('getParams')->nullable();
                $table->longText('postParams')->nullable();
                $table->timestamps();
            });

        if (!Schema::hasTable('stripe_info')) {
            Schema::create('stripe_info', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('user_id');
                $table->longText('stripe_id');
                $table->timestamps();
            });

        }
    }

    /**
     * Uninstall stripe module
     */
    static function uninstall()
    {
        Schema::dropIfExists('stripe_transactions');
        Schema::dropIfExists('stripe_payment_history');
        Schema::dropIfExists('stripe_info');
    }
}