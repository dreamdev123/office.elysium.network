<?php
/**
 *  -------------------------------------------------
 *  Hybrid MLM  Copyright (c) 2018 All Rights Reserved
 *  -------------------------------------------------
 *
 *  @author Acemero Technologies Pvt Ltd
 *  @link https://www.acemero.com
 *  @see https://www.hybridmlm.io
 *  @version 1.00
 *  @api Laravel 5.4
 */

return [

    /*
    |--------------------------------------------------------------------------
    | Stripe Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'click_to_pay_through_stripe' => 'click to pay through stripe',
    'proceed' => 'Proceed',
    'payment_success' => 'Payment success',
    'done_payment' => 'You have done payment successfully.',
    'stripe' => 'Stripe',
    'publish_key' => 'Publishable key',
    'secret_key' => 'Secret key',
    'end_point_secret' => 'End point secret',
    'client_id' => 'Client id',
    'Account_no' => 'Account No',
    'IFSC' => 'IFSC',
    'Please_select_the_account_to_withdraw' => 'Please select the account to withdraw',
    'Add_new' => 'Add new',
    'Back' => 'Back',
    'Save' => 'Save',
    'Please_enter_account_number' => 'Please enter account number',
    'Please_enter_ifsc' => 'Please enter IFSC',
    'New_account' => 'New Account',
    'please_proceed_with_stripe' => 'Please Proceed your payout with Stripe',
    'submit' => 'Submit',
    'please_connect_stripe' => 'Please click here to connect you\'re account to stripe',
    'connect' => 'Connect',
    'check_your_account' => 'Please click proceed to continue after connectingyour account with stripe',
    'verify' => 'Proceed',
    'stripe_info' => 'Stripe Info',
    'email' => 'Email',
    'stripe_id' => 'Stripe Id'
];