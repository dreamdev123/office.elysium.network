<link href="{{ asset('global/plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ asset('global/plugins/line-awesome-master/dist/css/line-awesome-font-awesome.css') }}" rel="stylesheet" type="text/css"/>
<script src="{{ asset('global/plugins/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
<div class="row" style="margin:0px;">
    <div class="col-sm-6 col-sm-offset-3">
        <div class="paymentSuccess">
            <i class="fa fa-check"></i>
            <p style="font-size: 18px;">Your Payment details has been completed successfully</p>
            <a href="{{ $redirectPath }}"><button type="button" class="btn blue"><i class="fa fa-home"></i> Back</button></a>
        </div>
    </div>
</div>
<style>
    body {
        background-color: #eee;
    }
    .paymentSuccess {
        text-align: center;
        background-color: #fff;
        box-shadow: #dddddd6b 5px 4px 0px;
        margin: 90px 0px;
        padding: 45px 22px;
        border: solid 1px #d6d6d6;
    }
    .paymentSuccess i {
        font-size: 54px;
        color: #1bb908;
        margin-bottom: 10px;
    }

    .paymentSuccess p {
        font-size: 20px;
    }

    button.btn.blue {
        background-color: #0fc3a7;
        color: #fff;
        font-size: 16px;
        margin: 15px 0px;
    }

    .paymentSuccess button.btn.blue i {
        font-size: 16px;
        color: #fff;
        margin: 0px;
    }
</style>
