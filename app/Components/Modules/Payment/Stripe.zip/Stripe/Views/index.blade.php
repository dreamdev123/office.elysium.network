<script src="https://js.stripe.com/v3/"></script>
@foreach($styles as $style)
    {!! $style !!}
@endforeach
<div class="stripeWrap">
    <div class="formWrapper">
        <div class="error"></div>
        <div class="stripeBox col-sm-10 col-sm-offset-1">
            <div class="col-sm-3 stripeIcon">
                <img src="{{ $imagePath }}/stripe.png" class="img-responsive">
            </div>
            <div class="col-sm-9">
                <div class="stripeInstruction">
                    <i class="fa fa-exclamation"></i>
                    <div class="freejoinDescription">
                        {{_mt($id,'Stripe.click_to_pay_through_stripe')}}
                    </div>
                    <button class="btn green ladda-button registerMeStripe" type="button" data-style="contract">
                        {{_mt($id,'Stripe.proceed')}}
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<input type="hidden" name="moduleId" value="{{ $id }}">

<script type="text/javascript">

    $(function () {
        Ladda.bind('.ladda-button');
    });

    //Send registration

    $('.registerMeStripe').click('.registerMeStripe', function () {

        var options = {
            actionUrl: '{{ scopeRoute("payment.handler") }}',
            successCallBack: function (response) {
               // $('.stripeWrap').hide();
                $('body').append(response['result']['paymentForm']);
                $('.stripeButton').trigger('click');

            },
            failCallBack: function (response) {
                Ladda.stopAll();
                switch (response.status) {
                    case 422:
                        if (window.hasOwnProperty('paymentFailureCallback')) {
                            window.paymentFailureCallback(response);
                        }
                        break;
                    default:
                        break;
                }
            }
        };
        sendForm(options);
    });
</script>