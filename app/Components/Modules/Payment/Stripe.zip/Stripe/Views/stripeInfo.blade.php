<div class="stripeInfo">
    <ul class="stripeInfoTab">
        <li class="active" data-target="bank">{{ _mt($moduleId,'Stripe.stripe_info') }}</li>
    </ul>
    <div class="panel active">
        <div class="eachData">
            <label>{{ _mt($moduleId,'Stripe.email') }} :</label>
            <span class="value">{{ $stripeInfo ? $stripeInfo->user->email : 'NA' }}</span>
        </div>
        <div class="eachData">
            <label>{{ _mt($moduleId,'Stripe.stripe_id') }} :</label>
            <span class="value">{{ $stripeInfo ? $stripeInfo->stripe_id : 'NA'}}</span>
        </div>
    </div>
</div>