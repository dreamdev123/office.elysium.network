@extends(ucfirst(getScope()).'.Layout.master')
@section('content')

<a href="https://connect.stripe.com/express/oauth/authorize?client_id={{ $clientId }}&state={{ $loggedId }}&suggested_capabilities[]=transfers&stripe_user[email]={{ $loggedEmail }}">connect</a>

    {{--    <button id="checkout-button" data-secret="{{ $session->id }}">--}}
{{--        Checkout--}}
{{--    </button>--}}

{{--    <script>--}}
{{--        var stripe = Stripe('pk_test_51HD2jZF0PGKOsAdzSDfn1ZLm5QYIjuTDOpVSrIZ5uApSX44Yv4O3hGW1Z7TALC5BLDz5fxQknb8P2G0WNnL7kjKh00ha6aXQgy');--}}

{{--        var checkoutButton = document.getElementById('checkout-button');--}}

{{--        checkoutButton.addEventListener('click', function() {--}}
{{--            stripe.redirectToCheckout({--}}
{{--                // Make the id field from the Checkout Session creation API response--}}
{{--                // available to this file, so you can provide it as argument here--}}
{{--                --}}{{--// instead of the {{CHECKOUT_SESSION_ID}} placeholder.--}}
{{--                sessionId: '{{ $session->id }}'--}}
{{--            }).then(function (result) {--}}
{{--                // If `redirectToCheckout` fails due to a browser or network--}}
{{--                // error, display the localized error message to your customer--}}
{{--                // using `result.error.message`.--}}
{{--            });--}}
{{--        });--}}

{{--    </script>--}}
@endsection
