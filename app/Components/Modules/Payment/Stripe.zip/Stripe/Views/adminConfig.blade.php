@foreach($scripts as $script)
    <script type="text/javascript" src="{{ $script }}"></script>
@endforeach
@foreach($styles as $style)
    <link href="{{ $style }}" rel="stylesheet" type="text/css"/>
@endforeach

<div class="moduleSettingsWrapper">
    <h3><img src="{{ $imagePath }}/stripe.png">
{{--        {{ _mt($moduleId,'Stripe.stripe') }}--}}
    </h3>
    {!! Form::open(['route' => ['admin.module.configure', $moduleId], 'class' => 'form-horizontal adminConfig','id' => 'adminconfig']) !!}
    <input type="hidden" value="{{ $moduleId }}" name="module_id">
        <div class="configPart1">
            <div class="formField row">
                <div class="col-md-4">
                    <span class="type">{{ _mt($moduleId,'Stripe.publish_key') }} </span><span class="required"> * </span>
                </div>
                <div class="col-md-8">
                    <div class="inputHolder flex">
                        <i class="fa fa-key"></i>
                        <input type="password" name="module_data[publish_key]" value="{{ $config->get('publish_key') }}">
                    </div>
                </div>
            </div>
            <div class="formField row">
                <div class="col-md-4">
                    <span class="type">{{ _mt($moduleId,'Stripe.secret_key') }} </span><span
                            class="required"> * </span>
                </div>
                <div class="col-md-8">
                    <div class="inputHolder flex">
                                                <i class="fa fa-key"></i>
                        <input type="password" name="module_data[secret_key]" value="{{ $config->get('secret_key') }}">
                    </div>
                </div>
            </div>
            <div class="formField row">
                <div class="col-md-4">
                    <span class="type">{{ _mt($moduleId,'Stripe.end_point_secret') }} </span><span
                            class="required"> * </span>
                </div>
                <div class="col-md-8">
                    <div class="inputHolder flex">
                        <i class="fa fa-key"></i>
                        <input type="password" name="module_data[end_point_secret]" value="{{ $config->get('secret_key') }}">
                    </div>
                </div>
            </div>
            <div class="formField row">
                <div class="col-md-4">
                    <span class="type">{{ _mt($moduleId,'Stripe.client_id') }} </span><span
                            class="required"> * </span>
                </div>
                <div class="col-md-8">
                    <div class="inputHolder flex">
                        <i class="fa fa-key"></i>
                        <input type="password" name="module_data[client_id]" value="{{ $config->get('client_id') }}">
                    </div>
                </div>
            </div>
        </div>
    <div class="row form-group">
        <div class="col-sm-offset-3 col-md-3">
            <button type="button" value="save"
                    class="form-control ladda-button btn green button-submit" data-style="contract"
                    name="amount">Save
            </button>
        </div>
    </div>
        <div class="errorWrapper" style="display: none"></div>
    {!! Form::close() !!}
</div>
<script>
    $(function () {

        var form = $('#adminconfig');

        $('.button-submit').click(function () {

            let errorWrapper = $('.errorWrapper').slideUp().empty();

            var successCallBack = function (response) {
                Ladda.stopAll();
                toastr.success("Configuration saved");
            };

            var failCallBack = function (response) {
                Ladda.stopAll();
                let errors = response.responseJSON;

                for (let key in errors)
                    errorWrapper.append('<div class="error">' + errors[key] + '</div>');

                errorWrapper.slideDown();
            };

            var options = {
                form: form,
                actionUrl: "{{ route('admin.module.save',['module_id' => $moduleId]) }}",
                successCallBack: successCallBack,
                failCallBack: failCallBack
            };
            sendForm(options);
        });
    });

</script>
