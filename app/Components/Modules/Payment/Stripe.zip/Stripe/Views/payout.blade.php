@foreach($scripts as $script)
    <script src="{{ $script }}" type="text/javascript"></script>
@endforeach
@foreach ($styles as $style)
    <link href="{{ $style }}" rel="stylesheet"
          type="text/css"/>
@endforeach
<div class="stripe stripePayout">
    @if($stripeAccount)
        <div class="stripePayoutAccount">
            <input type="hidden" name="account" id="account" value="{{ $stripeAccount->id }}">
            <h3>{{ _mt($moduleId,'Stripe.please_proceed_with_stripe') }}</h3>
            <button class="btn btn-outline green btn-circle ladda-button submitPayout" type="button"
                    data-style="contract">
                <i class="fa fa-check"></i> {{ _mt($moduleId,'Stripe.submit') }}
            </button>
        </div>
    @else
        <div class="connectToStripe">
            <h3>{{ _mt($moduleId,'Stripe.please_connect_stripe') }}</h3>
            <button type="button" class="btn  btn-outline green btn-circle Connect"
                    data-style="contract">{{ _mt($moduleId,'Stripe.connect') }}
            </button>
        </div>
        <div class="stripeMessage" style="display: none">
            <h3>{{ _mt($moduleId,'Stripe.check_your_account') }}</h3>
            <button type="button" class="btn  btn-outline green btn-circle Verify"
                    data-style="contract">{{ _mt($moduleId,'Stripe.verify') }}
            </button>
        </div>
        <input type="hidden" name="account" id="account">
</div>
<div class="stripePayoutActions" style="display: none">
    <h3>{{ _mt($moduleId,'Stripe.please_proceed_with_stripe') }}</h3>
    <button class="btn btn-outline green btn-circle ladda-button submitPayout" type="button" data-style="contract">
        <i class="fa fa-check"></i> {{ _mt($moduleId,'Stripe.submit') }}
    </button>
</div>
@endif

<script>
    $('.Connect').click(function () {
        window.open('https://connect.stripe.com/express/oauth/authorize?client_id={{ $clientId }}&state={{ $loggedId }}&stripe_user[email]={{ $loggedEmail }}', '_blank');
        $('.connectToStripe').hide();
        $('.stripeMessage').show();
    });

    $('.Verify').click(function () {
        $.post('{{ scopeRoute('checkUserDetails') }}', function (response) {
            if (response.id) {
                $('#account').val(response.id);
                $('.stripeMessage').slideUp();
                $('.stripePayoutActions').slideDown();
            } else {
                $('')
            }
        });
    });

    $('.submitPayout').click(function (e) {
        e.preventDefault();
        simulateLoading('.stripePayout');

        return $.post('{{ scopeRoute('payment.handler') }}', {
            context: 'payout',
            gateway: '{{ $moduleId }}',
            account: $('.stripePayout [name="account"]').val(),
        }, function (response) {
            simulateLoading('.stripePayout', true);
            $('.payoutSuccess').slideDown().siblings().slideUp();
            $('button.previousStep').slideUp();
            Ladda.stopAll();
        }).fail(function (response) {
            Ladda.stopAll();

            simulateLoading('.stripePayout', true);
        });
    });
</script>
<style>
    .stripePayoutAccount {
        border: solid 1px #eee;
        padding: 12px 10px;
        text-align: center;
    }
    .stripePayoutAccount h3 {font-weight: 500;font-size: 20px;}

    .connectToStripe {
        border: solid 1px #eee;
        padding: 12px 10px;
        text-align: center;
    }
    .connectToStripe h3 {font-weight: 500;font-size: 20px;}

    .stripeMessage {
        border: solid 1px #eee;
        padding: 12px 10px;
        text-align: center;
    }
    .stripeMessage h3 {font-weight: 500;font-size: 20px;}

    .stripePayoutActions {
        border: solid 1px #eee;
        padding: 12px 10px;
        text-align: center;
    }
    .stripePayoutActions h3 {font-weight: 500;font-size: 20px;}
</style>