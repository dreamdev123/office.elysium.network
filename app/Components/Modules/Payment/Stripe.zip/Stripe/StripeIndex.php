<?php
/**
 *  -------------------------------------------------
 *  Hybrid MLM  Copyright (c) 2018 All Rights Reserved
 *  -------------------------------------------------
 *
 * @author Acemero Technologies Pvt Ltd
 * @link https://www.acemero.com
 * @see https://www.hybridmlm.io
 * @version 1.00
 * @api Laravel 5.4
 */

namespace App\Components\Modules\Payment\Stripe;

use App\Blueprint\Interfaces\Module\PaymentModuleAbstract;
use App\Blueprint\Interfaces\Module\PayoutGatewayInterface;
use App\Blueprint\Services\PaymentServices;
use App\Blueprint\Services\TransactionServices;
use App\Blueprint\Support\Transaction\Payable;
use App\Components\Modules\General\Payout\ModuleCore\Eloquents\PayoutRequest;
use App\Components\Modules\Payment\BankWire\ModuleCore\Services\BankWireServices;
use App\Components\Modules\Payment\Paytm\ModuleCore\Eloquents\PaytmTransaction;
use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeInfo;
use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeTransaction;
use http\Exception;
use Illuminate\Contracts\View\View;
use App\Components\Modules\Payment\Stripe\ModuleCore\Traits\Hooks;
use App\Components\Modules\Payment\Stripe\ModuleCore\Traits\Routes;
use Illuminate\Http\Request;
use Stripe\Stripe;
require_once __DIR__ . '/ModuleCore/vendor/autoload.php';



/**
 * Class StripeIndex
 * @package App\Components\Modules\Payment\Stripe
 */
class StripeIndex extends PaymentModuleAbstract implements PayoutGatewayInterface
{
    use Hooks, Routes;

    /**
     * Register providers
     */
    function providers()
    {

    }

    /**
     * handle admin settings
     */
    function adminConfig()
    {
        $config = collect([]);
        if ($this->getModuleData()) $config = $this->getModuleData(true);

        $data = [
            'styles' => [
                $this->getCssPath('style.css')
            ],
            'scripts' => [],
            'moduleId' => $this->moduleId,
            'config' => $config,
            'imagePath' => $this->getAssetsPath('Images'),
        ];

        return view('Payment.Stripe.Views.adminConfig', $data);
    }

    /**
     * Payment page View
     *
     * @return View
     * @throws Throwable
     */
    function renderView()
    {
        $data = [
            'styles' => [
                $this->addCss('style.css')],
            'id' => $this->moduleId,
            'imagePath' => getModule($this->moduleId)->getAssetsPath('Images'),
        ];

        return view('Payment.Stripe.Views.index', $data);
    }

    /**
     * Process Payment
     *
     * @param Payable $payable
     * @param TransactionServices $transactionServices
     * @param PaymentServices $paymentServices
     * @return array
     * @throws Throwable
     */
    function processPayment(Payable $payable, TransactionServices $transactionServices, PaymentServices $paymentServices)
    {
        $config = $this->getModuleData('true');

        $data['config'] = $config;

        // Setting necessary vars in Payable
        $payable->setFromModule($this->moduleId);
        // Adding transaction record with operation details
        $transaction = $transactionServices
            ->processTransaction($payable)
            ->setOperation()
            ->setCharges()->getTransaction();

        $transaction->update(['status' => false]);


        Stripe::setApiKey($config->get('secret_key'));

        $session = \Stripe\Checkout\Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => 'sgd',
                    'product_data' => [
                        'name' => getConfig('company', 'company_name'),
                    ],
                    'unit_amount' => $transaction->amount * 100,
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => route('stripe.successUrl'),
            'cancel_url' => route('stripe.cancelUrl'),
        ]);

        $data['session'] = $session;
        $nextAction = 'pending';
        $context = $payable->getContext();

        StripeTransaction::create([
            'session_id' => $session->id,
            'callback' => get_class($paymentServices->getCallback()),
            'amount' => $transaction->amount,
            'local_txn_id' => $transaction->id,
            'context' => $payable->getContext(),
            'data' => defineFilter("{$nextAction}CallbackResponse", [], $context, $transaction),
            'status' => 0
        ]);

        $paymentForm = view('Payment.Stripe.Views.payment', $data)->render();

        return ['next' => 'pending', 'orderStatus' => 1, 'paymentForm' => $paymentForm, 'transaction' => $transaction->transaction];

    }

    /**
     * @param int $digits
     * @return bool|string
     */
    function generateCustomerId($digits = 6)
    {
        return substr(str_shuffle("0123456789"), 0, $digits);
    }

    /**
     * @return array|string[]
     */
    function moduleDataValidationRules()
    {
        return [
            'module_data.publish_key' => 'required',
            'module_data.secret_key' => 'required',
            'module_data.end_point_secret' => 'required',
        ];
    }

    function moduleDataValidationAttributes()
    {
        return [
            'module_data.publish_key' => 'Publishable key',
            'module_data.secret_key' => 'Secret key',
            'module_data.end_point_secret' => 'End point secret',
        ];
    }

    /**
     * Get the preferred payable object
     *
     * @return mixed
     */
    function getPayable()
    {
        return Payable::class;
    }

    /**
     * handle module installations
     *
     * @return void
     */
    function install()
    {
        ModuleCore\Schema\Setup::install();
    }

    /**
     * handle module un-installation
     */
    function uninstall()
    {
        ModuleCore\Schema\Setup::uninstall();
    }

    /**
     * Process Payment
     *
     * @param PaymentServices $paymentServices
     * @return mixed
     */
    function validatePayment(PaymentServices $paymentServices)
    {
        return false;
    }

    /**
     * Process Payout
     *
     * @param Payable $payable
     * @param TransactionServices $transactionServices
     * @return mixed
     */
    function processPayout(Payable $payable, TransactionServices $transactionServices)
    {
        // Setting necessary vars in Payable
        $payable->setFromModule($this->moduleId);
        // Adding transaction record with operation details
        $transaction = $transactionServices
            ->processTransaction($payable)
            ->setOperation()
            ->setCharges()->getTransaction();

        return ['next' => 'success', 'orderStatus' => 1, 'transaction' => $transaction];
    }


    /**
     * @param $amount
     * @param $key
     * @return array|\Illuminate\Http\JsonResponse
     * @throws \Stripe\Exception\ApiErrorException
     */
    function processRequestedPayout($amount, $key)
    {
        $payoutRequest = PayoutRequest::find($key)->account;
        $account = StripeInfo::find($payoutRequest);
        $moduleData = getModule('Payment-Stripe')->getModuleData(true);

        \Stripe\Stripe::setApiKey($moduleData->get('secret_key'));

        try {
            $transfer = \Stripe\Transfer::create([
                "amount" => $amount * 100,
                "currency" => "sgd",
                "destination" => $account->stripe_id,
            ]);
        } catch (Exception $e) {
            return response()->json(['error' => 'An unknown error occurred.'], 500);
        }

        if($transfer){
            return [
                'status' => 'success'
            ];
        }
    }

    /**
     * @param Request $request
     * @return mixed
     */
    function payoutView(Request $request = null)
    {
        $moduleData = getModule('Payment-Stripe')->getModuleData(true);

        $data = [
            'scripts' => [
                asset('global/plugins/owl-carousel_old/owl.carousel.min.js'),
            ],
            'styles' => [
                $this->getCssPath('payout.css'),
                asset('global/plugins/owl-carousel_old/owl.carousel.css'),
                asset('global/plugins/owl-carousel_old/owl.theme.css'),
            ],
            'clientId' => $moduleData->get('client_id'),
            'loggedId' => loggedId(),
            'loggedEmail' => loggedUser()->email,
            'moduleId' => $this->moduleId,
            'stripeAccount' => StripeInfo::where('user_id', loggedId())->first(),
        ];

        return view('Payment.Stripe.Views.payout', $data);
    }
}
