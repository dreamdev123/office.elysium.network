<?php
/**
 *  -------------------------------------------------
 *  Hybrid MLM  Copyright (c) 2018 All Rights Reserved
 *  -------------------------------------------------
 *
 * @author Acemero Technologies Pvt Ltd
 * @link https://www.acemero.com
 * @see https://www.hybridmlm.io
 * @version 1.00
 * @api Laravel 5.4
 */

namespace App\Components\Modules\Payment\Stripe\Controllers;

use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeHistory;
use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeInfo;
use App\Components\Modules\Payment\Stripe\ModuleCore\Eloquents\StripeTransaction;
use App\Components\Modules\Payment\Stripe\StripeIndex as Module;
use App\Eloquents\Transaction;
use App\Http\Controllers\Controller;
use http\Exception;
use Illuminate\Http\Request;
use Stripe\Stripe;


require_once __DIR__ . '/../ModuleCore/vendor/autoload.php';


/**
 * Class StripeController
 * @package App\Components\Modules\Payment\Stripe\Controllers
 */
class StripeController extends Controller
{
    protected $module;

    /**
     * __construct function
     */
    function __construct()
    {
        parent::__construct();
        $this->module = app()->make(Module::class);

    }

    /**
     * @param Request $request
     */
    function callBack(Request $request)
    {
        $config = $this->module->getModuleData('true');
        StripeHistory::create([
                'getParams' => $_GET,
                'postParams' => json_decode(file_get_contents('php://input'), true)
            ]
        );

        // Set your secret key. Remember to switch to your live secret key in production!
        // See your keys here: https://dashboard.stripe.com/account/apikeys
        Stripe::setApiKey($config->get(''));

        // You can find your endpoint's secret in your webhook settings
        $endpoint_secret = $config->get('end_point_secret');

        $payload = @file_get_contents('php://input');
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
        $event = null;

        try {
            $event = \Stripe\Webhook::constructEvent(
                $payload, $sig_header, $endpoint_secret
            );
        } catch (\UnexpectedValueException $e) {
            // Invalid payload
            http_response_code(400);
            exit();
        } catch (\Stripe\Exception\SignatureVerificationException $e) {
            // Invalid signature
            http_response_code(400);
            exit();
        }


        // Handle the checkout.session.completed event
        if ($event->type == 'checkout.session.completed') {
            $session = $event->data->object;
            $stripeTransaction = StripeTransaction::where('session_id', $session->id)->where('status', 0)->first();

            $callback = new $stripeTransaction->callback;
            app()->call([$callback, 'success'], ['response' => $stripeTransaction->data]);
            StripeTransaction::where('session_id', $session->id)->update(['status' => 1]);
            Transaction::find($stripeTransaction->local_txn_id)->update(['status' => 1]);
        }

        http_response_code(200);
    }


//    function addNewBankAccount(Request $request)
//    {
////        $this->validate($request, [
////            'account_number' => 'required',
//////            'ifsc_code' => 'required',
////        ]);
//
//        $request['user_id'] = loggedId();
//
//        return response()->json(StripeInfo::create($request->only($this->allowedFields())));
//    }
//
//    /**
//     * @return array
//     */
//    function allowedFields()
//    {
//        return ['stripe_id', 'user_id'];
//    }


    function test()
    {
        $moduleData = getModule('Payment-Stripe')->getModuleData(true);

        $data = [
            'clientId' => $moduleData->get('client_id'),
            'loggedId' => loggedId(),
            'loggedEmail' => loggedUser()->email,
        ];

        return view('Payment.Stripe.Views.test', $data);

    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Foundation\Application|\Illuminate\View\View
     */
    public function successUrl()
    {

        $data = [
            'redirectPath' => loggedId() ? route(loggedUser()->userType->title . '.home') : route('user.login')
        ];

        return view('Payment.Stripe.Views.paymentSuccess', $data);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Foundation\Application|\Illuminate\View\View
     */
    public function cancelUrl()
    {
        $data = [
            'redirectPath' => loggedId() ? route(loggedUser()->userType->title . '.home') : route('user.login')
        ];

        return view('Payment.Stripe.Views.paymentFailed', $data);
    }

    function individualConnectCallback()
    {

        $state = request()->input('state');
        $code = request()->input('code');
        $moduleData = getModule('Payment-Stripe')->getModuleData(true);

        \Stripe\Stripe::setApiKey($moduleData->get('secret_key'));


        if (!$this->stateMatches($state))
            return response()->json(['error' => 'Incorrect state parameter: ' . $state], 403);

        // Send the authorization code to Stripe's API.
        try {
            $stripeResponse = \Stripe\OAuth::token([
                'grant_type' => 'authorization_code',
                'code' => $code,
            ]);
        } catch (\Stripe\Error\OAuth\InvalidGrant $e) {
            return response()->json(['error' => 'Invalid authorization code: ' . $code], 400);
        } catch (Exception $e) {
            return response()->json(['error' => 'An unknown error occurred.'], 500);
        }

        $connectedAccountId = $stripeResponse->stripe_user_id;
        $account = $this->saveAccountId($connectedAccountId);
        $data['redirectPath'] = loggedId() ? getenv('APP_URL') . '/' . loggedUser()->userType->title . '/home' : route('user.login');

        if ($account) {
            return view('Payment.Stripe.Views.paymentSuccess', $data);
        } else {
            return view('Payment.Stripe.Views.paymentFailed', $data);
        }

//        return response()->json(['success' => true], 200);
//
//        echo 'create a view and show success message show do not refresh this window';
//        // Render some HTML or redirect to a different page.
//        return response()->withStatus(200)->withJson(array('success' => true));

    }

    /**
     * @param $stateParameter
     * @return bool
     */
    function stateMatches($stateParameter)
    {
        // Load the same state value that you randomly generated for your OAuth link.
        $savedState = loggedId();

        return $savedState == $stateParameter;
    }


    /**
     * @param $id
     * @return StripeInfo|bool|\Illuminate\Database\Eloquent\Model
     */
    function saveAccountId($id)
    {
        // Save the connected account ID from the response to your database.

//        acct_1HG6GxHO1G3dhR9G

        if (StripeInfo::where('user_id', loggedId())->exists()) {
         return $account = StripeInfo::where('user_id', loggedId())->update([
                'user_id' => loggedId(),
                'stripe_id' => $id,
            ]);
        } else {
            return $account =  StripeInfo::create([
                'user_id' => loggedId(),
                'stripe_id' => $id,
            ]);
        }

    }

    function testPayout()
    {

        $moduleData = getModule('Payment-Stripe')->getModuleData(true);

        \Stripe\Stripe::setApiKey($moduleData->get('secret_key'));

        try {
            $transfer = \Stripe\Transfer::create([
                "amount" => 1,
                "currency" => "sgd",
                "destination" => "acct_1HG6GxHO1G3dhR9G",
            ]);
        } catch (Exception $e) {
            return response()->json(['error' => 'An unknown error occurred.'], 500);
        }


        dd($transfer);
    }

    function checkUserDetails()
    {
        $account = StripeInfo::where('user_id', loggedId())->first();
        if ($account) {
            return response()->json([
                'status' => true,
                'id' => $account->id,
            ]);
        }

        return response()->json([
        'message' => 'not connected yet',
    ],422);
    }

}